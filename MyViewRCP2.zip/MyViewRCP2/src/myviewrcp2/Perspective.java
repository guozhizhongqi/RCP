package myviewrcp2;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

public class Perspective implements IPerspectiveFactory {

	public static final String ID = "MyViewRCP2.perspective"; //$NON-NLS-1$
	@Override	
	public void createInitialLayout(IPageLayout layout) {
		String editorArea = layout.getEditorArea(); 
        //��������ͼ 
        layout.addView(SampleView.ID, IPageLayout.LEFT, 0.2f, editorArea); 
        layout.addView(AnotherView.ID, IPageLayout.LEFT, 1f, editorArea); 
	}
}
