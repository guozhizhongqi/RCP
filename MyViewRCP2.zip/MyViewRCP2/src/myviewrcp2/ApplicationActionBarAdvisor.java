package myviewrcp2;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.ICoolBarManager;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;

public class ApplicationActionBarAdvisor extends ActionBarAdvisor {

	private NewAction newAction;//�Զ����action
	private IWorkbenchAction exitAction; //�˳�
	private IWorkbenchAction aboutAction; //����
	
	public ApplicationActionBarAdvisor(IActionBarConfigurer configurer) {
		super(configurer);
	}
	
	@Override
	protected void makeActions(IWorkbenchWindow window) {
		newAction = new NewAction(); //����action����
		register(newAction); //���෽����ע��ò���
		exitAction = ActionFactory.QUIT.create(window); //Eclipse���õ��˳�����
		register(exitAction);
		aboutAction = ActionFactory.ABOUT.create(window); //���õĹ��ڲ���
		register(aboutAction);
	}
	
	//���Ǹ����еķ����������˵���
	@Override
	protected void fillMenuBar(IMenuManager menuBar) {
		MenuManager codeMenu = new MenuManager("CodeMenu(&C)");
		codeMenu.add(newAction);
		codeMenu.add(aboutAction);
		codeMenu.add(exitAction);
		menuBar.add(codeMenu);
	}
	
	//���Ǹ����еķ���������������
	@Override
	protected void fillCoolBar(ICoolBarManager coolBar) {
		IToolBarManager toolbar = new ToolBarManager(coolBar.getStyle());
		toolbar.add(aboutAction);
		toolbar.add(newAction);
		coolBar.add(toolbar);
	}
	
	class NewAction extends Action {
		NewAction(){
			super("new");
			this.setId("NewAction");
		}
		public void run() {}
	}

}

