package myviewrcp2;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

public class AnotherView extends ViewPart{

	private Text text;//�ı���
	public static final String ID = "myviewrcp2.AnotherView";
	
	public AnotherView() {
		super();
	}
	@Override
	public void createPartControl(Composite parent) {
		// TODO Auto-generated method stub
		text = new Text(parent,SWT.NONE);
	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub
		this.setFocus();
	}
	
	//�����ı��������
	public void setContent(String content) {
		text.setText(content);
	}

}
